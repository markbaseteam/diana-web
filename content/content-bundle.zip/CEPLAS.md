# Exzellenzcluster für Pflanzenwissenschaften - SMARTe Pflanzen für die Anforderungen von morgen

## Worum geht es?
CEPLAS ist der einzige Exzellenzcluster Deutschlands auf dem Gebiet der Pflanzenforschung. Das wissenschaftliche Ziel des Clusters ist, durch die Erforschung der Grundlagen und des Zusammenspiels komplexer Pflanzenmerkmale, die einen Einfluss auf die Anpassung an begrenzte Ressourcen und den Ertrag haben, die Grundlage für die Entwicklung und Züchtung von (Nutz-)Pflanzen zu legen, die vorhersagbar auf künftige Herausforderungen reagieren („SMARTe Pflanzen“). CEPLAS bündelt die Ressourcen der Universitäten Düsseldorf und Köln, des Max-Planck- Instituts für Pflanzenzüchtungsforschung und des Forschungszentrums Jülich zu einem international führenden Zentrum für Pflanzenforschung, welches erstklassige Wissenschaftler*innen anzieht.

## Laufzeit
2019-2025

## Fördervolumen
42 Mio. €

## Wer ist dabei?
Heinrich-Heine-Universität Düsseldorf
Universität zu Köln 
Max-Planck-Institut für Pflanzenzüchtungsforschung Köln
Forschungszentrum Jülich

## Link
https://www.ceplas.eu/
