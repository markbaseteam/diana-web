# Entwicklung von standardisierten Aufnahme- und Auswertungsroutinen für den Einsatz von unbemannten Fluggeräten in der Pflanzenzüchtung und Sortenprüfung

Veränderte Umweltbedingungen und der Bedarf an ertragsstabilen Sorten stellt die Pflanzenzüchtung vor erhebliche Herausforderungen bei der Phänotypisierung mehrjähriger Feldversuche an verschiedenen Standorten. Der Einsatz von Coptern und optischen Kameras bietet indes ein hohes Potenzial zum kostengünstigen Hochdurchsatz, zur Objektivierung der Ergebnisse und zur Aufnahme zusätzlicher Merkmale.

Das Vorhaben wird in Zusammenarbeit folgender Partner durchgeführt:
-   Julius Kühn-Institut (JKI), Forschungszentrum für landwirtschaftliche Fernerkundung (FLF)
-   Hochschule Osnabrück
-   Gemeinschaft zur Förderung von Pflanzeninnovation e.V. (GFPi)

https://www.ble.de/DE/Projektfoerderung/Foerderungen-Auftraege/Ackerbaustrategie/Innovationen-ABS/StandardsDroPhe.html
