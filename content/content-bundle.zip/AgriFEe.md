# Koppelung von Photovoltaik und Pflanzenproduktion

## Worum geht es?
Im Innovationslabor Agri Food-Energy-Park (AgriFEe) wird der flächeneffiziente Einsatz von Agri-/Horti-Photovoltaik unter den im Rheinischen Revier herrschenden Bedingungen untersucht. In einer Demonstrationsanlage bei Morschenich-Alt wachsen auf etwa zwei Hektar testweise verschiedene hochwertige Pflanzen wie Beerensträucher sowie Medizinal- und Aromapflanzen unter rund tausend Solarmodulen.

## Laufzeit
1. Förderperiode: 01.12.2019 - 31.12.2021 (APV 2.0)
2. Förderperiode: 01.01.2022 – 31.12.2026 (AgriFEe)

## Wer ist dabei?
Forschungszentrum Jülich GmbH, Institut für Pflanzenwissenschaften
Forschungszentrum Jülich GmbH, Institut für Photovoltaik 
Fraunhofer-Institut für Solare Energiesysteme (ISE)

## Link
https://www.biooekonomierevier.de/Innovationslabor_APV_2_0
