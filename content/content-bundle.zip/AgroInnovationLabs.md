# Feldlabore für ressourceneffiziente Pflanzenproduktion

## Worum geht es?
In den AgroInnovationLabs im Rheinischen Revier erproben Forscher:innen, Unternehmen und Landwirt:innen in Feldlaboren unter weltweit einmaligen Bedingungen neue Pflanzenmanagement- und Kultivierungssysteme auf Versuchsstandorten mit unterschiedlichen Marginalitätsstufen. Hier werden unter anderem Anbausysteme für nicht rekultivierte Tagebaurestflächen entwickelt und die Aufwertung der Bodenfruchtbarkeit getestet.

## Laufzeit
1. Förderperiode: 01.12.2019 - 31.12.2021 (Marginal Field Lab)
2. Förderperiode: 01.01.2022 - 31.12.2026 (AgroInnovationLabs)

## Wer ist dabei?
Forschungszentrum Jülich GmbH, Institut für Pflanzenwissenschaften

## Link
https://www.biooekonomierevier.de/Innovationslabor_Marginal_Field_Lab_MFL

<iframe width="560" height="315" src="https://www.youtube.com/embed/1wVxIhVRqN8?si=1Z0YVjy6mtOnJ2Gj" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
