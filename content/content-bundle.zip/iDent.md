# Sensorsystem für ein echtzeitfähiges Nährstoffmanagement zur bedarfsgerechten Düngung in der Landwirtschaft

https://elektronikforschung.de/projekte/ident