## Worum geht es?
Bodenbearbeitung und Unkrautbekämpfung sind zwei der wichtigsten Aufgaben, die die Landwirte heute wahrnehmen. Eine aktuelle Herausforderung für die Unkrautbekämpfung ist der Wunsch, den Einsatz von Herbiziden und Pestiziden und gleichzeitig die Qualität und Quantität der Ernte zu erhalten. In diesem Beitrag stellen wir BonnBot-I vor, eine Plattform für präzises Unkrautmanagement die auch die Feldüberwachung übernehmen kann. Angetrieben von Pflanzen
die Pflanzen genau lokalisieren und klassifizieren können Pflanzen (Unkraut und Feldfrüchte), verbessern wir deren Leistung weiter indem wir die auf der Plattform verfügbare GNSS- und Rad-Odometrie fusionieren.

## Link
https://heise.de/-9238727 

