# Agrorobotik, KI und digitale Systeme für die Landwirtschaft

## Worum geht es?
Im Entwicklungs- und Testzentrum BrainergyLab dreht sich alles um die ressourcenoptimierte und moderne Landwirtschaft der Zukunft. Das Innovationslabor bietet Landwirt:innen, Unternehmen und Forscher:innen eine Plattform, um gemeinsam neue Technologien wie Agrarrobotik, digitale Systeme und künstliche Intelligenz zu erproben. Innovative Technologien können schneller für die praktische Anwendung qualifiziert und zukünftige Geschäftsfelder gezielt erschlossen werden.

## Laufzeit
1. Förderperiode: 01.12.2019 - 31.12.2021 (Brainergy Field Lab)
2. Förderperiode: 01.01.2022 - 31.12.2026 (BrainergyLab)

## Wer ist dabei?
Forschungszentrum Jülich GmbH, Institut für Pflanzenwissenschaften
FH Aachen, Institut für datenbasierte Technologien (IDT)

## Link
https://www.biooekonomierevier.de/Innovationslabor_Brainergy_Field_Lab_BFL
