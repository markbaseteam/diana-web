# Ganzheitliche Konzeption, feldbasierte Praxiserprobung und Validierung autonomer Arbeitsprozesse im Pflanzenbau

Ziel des NeXaTauto-Projekts ist es, dieses neuartige Konzept mittels sogenannter digitaler Zwillinge und Techniken der nichtlinearen Optimierung und Künstlichen Intelligenz autonom im Feld nutzbar zu machen und durch praktische Tests unter realen Bedingungen neue Erkenntnisse zu gewinnen.

https://www.math.uni-bremen.de/zetem/cms/detail.php?id=21953
https://www.hs-osnabrueck.de/nachrichten/2022/03/ein-autonomes-fahrzeug-fuer-die-landwirtschaft-der-zukunft/
