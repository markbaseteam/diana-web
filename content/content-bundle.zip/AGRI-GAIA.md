# Ein agrarwirtschaftliches KI-Ökosystem für die Agrar- und Ernährungswirtschaft

https://www.agri-gaia.de/
