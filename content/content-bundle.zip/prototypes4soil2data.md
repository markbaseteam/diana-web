# Modulare mobile Bodensensorik-Technologien für nachhaltiges Nährstoffmanagement

https://www.innovationstage-digital.de/forum-digital/mobiles-bodenproben-labor-und-datenfusion-im-pflanzenbau

