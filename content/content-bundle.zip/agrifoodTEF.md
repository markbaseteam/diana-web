
Osnabrück gilt längst als Größe bei der Digitalisierung der Landwirtschaft und Nahrungsmittelproduktion. Dem Dreigestirn aus Hochschule Osnabrück, Deutsches Forschungszentrum für Künstliche Intelligenz (DFKI) und Agrotech Valley Forum ist es gelungen, diese Position weiter zu festigen. Mit der Förderinitiative agrifoodTEF mit einem Gesamtvolumen von bis zu 50 Millionen Euro entsteht in Europa in aktuell drei Ländern jeweils ein Knoten aus Testumgebungen für KI und Agrarrobotik. In Deutschland laufen die Fäden in Osnabrück zusammen.

Unternehmen und Wissenschaftseinrichtungen aus ganz Europa können in der Region Osnabrück, Niedersachsen, künftig experimentieren und KI-Komponenten in Prototypen validieren, die es zur Marktreife schaffen sollen. Die Osnabrücker spezialisieren sich mit bis zu 10 Millionen Euro auf **Agrartechnik im Ackerbau**.

https://www.hs-osnabrueck.de/nachrichten/2023/02/agrifoodtef/

Webseite agrifoodTEF: [https://www.agrifoodtef.eu/](https://www.agrifoodtef.eu/)  
Webseite Agro-Technicum: [www.hs-osnabrueck.de/agro-technicum](http://www.hs-osnabrueck.de/agro-technicum)

